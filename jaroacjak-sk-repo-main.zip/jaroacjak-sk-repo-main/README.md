# jaroacjak-sk-repo

Tento repozitár slúži ako môj archív kódov a projektov v slovenčine.

## Čo tu nájdete:
* Moje programátorské pokusy
* Skripty a nástroje
* Dokumentáciu
* 
