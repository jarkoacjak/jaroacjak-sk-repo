import sys
import urllib.parse
import json
import os
import unicodedata
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

def build_url(query):
    return sys.argv[0] + '?' + urllib.parse.urlencode(query)

def remove_diacritics(text):
    """Odstráni diakritiku z textu pre lepšie vyhľadávanie (napr. ČRo -> CRo)"""
    normalized = unicodedata.normalize('NFKD', text)
    return "".join([c for c in normalized if not unicodedata.combining(c)])

def get_db_path():
    try:
        addon_profile = xbmcaddon.Addon().getAddonInfo('profile')
        profile_path = xbmcvfs.translatePath(addon_profile)
        if not profile_path:
            profile_path = xbmcvfs.translatePath(os.path.join('special://profile/addon_data', xbmcaddon.Addon().getAddonInfo('id')))
        if not xbmcvfs.exists(profile_path):
            xbmcvfs.mkdir(profile_path)
        return os.path.join(profile_path, 'data.json')
    except:
        return ""

def load_user_data():
    db_path = get_db_path()
    if db_path and os.path.exists(db_path):
        try:
            with open(db_path, 'r', encoding='utf-8') as f:
                return json.load(f)
        except:
            pass
    return {"custom": []}

def save_user_data(data):
    db_path = get_db_path()
    if db_path:
        try:
            with open(db_path, 'w', encoding='utf-8') as f:
                json.dump(data, f, ensure_ascii=False, indent=4)
        except:
            pass

def main():
    try:
        handle = int(sys.argv[1])
        arg_string = sys.argv[2][1:]
        params = dict(urllib.parse.parse_qsl(arg_string))
    except:
        return

    action = params.get('action')
    user_data = load_user_data()

    # --- DATABÁZA RÁDIÍ ---
    radia_sk = [
        {"nazov": "Moveit Rádio", "url": "https://play.radiosebastian.eu/listen/moveitradiosk/radio.mp3", "logo": "https://myonlineradio.sk/public/uploads/radio_img/moveit-radio/play_250_250.webp"},
        {"nazov": "Fun Rádio Leto", "url": "https://stream.funradio.sk:8000/summer128.mp3", "logo": "https://cdn.radia.sk/_radia/loga/app/fun-letne-hity.webp?v=11"},
        {"nazov": "Fun Rádio Mileniálky", "url": "https://stream.funradio.sk:8000/milenialky128.mp3", "logo": "https://cdn.radia.sk/_radia/loga/coverflow/fun-milenialky.png"},
        {"nazov": "Fun Rádio Dance", "url": "http://stream.funradio.sk:8000/dance128.mp3", "logo": "https://cdn.radia.sk/_radia/loga/coverflow/fun-dance.png"},
        {"nazov": "Fun Rádio Chill", "url": "https://stream.funradio.sk/chill128.mp3", "logo": "https://cdn.radia.sk/_radia/loga/coverflow/fun-chill.png"},
        {"nazov": "Fun Rádio 80's - 90's", "url": "http://stream.funradio.sk:8000/80-90-128.mp3", "logo": "https://cdn.radia.sk/_radia/loga/nadpis/fun-80-90-roky.webp?v=1"},
        {"nazov": "Fun Rádio CZ - SK", "url": "http://stream.funradio.sk:8000/cs128.mp3", "logo": "https://cdn.radia.sk/_radia/loga/coverflow/fun-cz-sk.png"},
        {"nazov": "V2Beat Radio", "url": "https://de1se01.v2beat.live/icecast.audio", "logo": "https://app.v2beat.com/images/viib-v2beat-logo-neon.jpg"},
        {"nazov": "Záhorácke Rádio", "url": "http://live.zahorackeradio.sk:8080/zr128.mp3", "logo": "https://cdn.radia.sk/_radia/loga/app/zahoracke.webp?v=1"},
        {"nazov": "Top Rádio", "url": "https://solid1.streamupsolutions.com/proxy/vhhggmih/stream", "logo": "https://cdn.radia.sk/_radia/loga/coverflow/top.png"},
        {"nazov": "Trnavské Rádio", "url": "https://solid33.streamupsolutions.com/proxy/mujdmamw/trnavske", "logo": "https://myonlineradio.sk/public/uploads/radio_img/trnavske-radio/play_250_250.webp"},
        {"nazov": "Rádio SUB FM", "url": "https://stream.subfm.sk/subfm", "logo": "https://cdn.radia.sk/_radia/loga/coverflow/sub-fm.png"},
        {"nazov": "Rádio Ticho", "url": "https://solid1.streamupsolutions.com/proxy/rpiipoer/tiche", "logo": "https://cdn.radia.sk/_radia/loga/coverflow/tiche.png"},
        {"nazov": "Sky Rádio", "url": "http://stream.skyradio.sk:8000/sky128", "logo": "https://cdn.radia.sk/_radia/loga/coverflow/sky.png"},
        {"nazov": "Rádio Slobodný Vysielač", "url": "https://vysielanie.online/radio/8020/SV128.mp3", "logo": "https://myonlineradio.sk/public/uploads/radio_img/slobodny-vysielac/play_250_250.webp"},
        {"nazov": "Rádio Zábava", "url": "https://stream.zeno.fm/eyac00cx1nhvv", "logo": "https://cdn.radia.sk/_radia/loga/app/zabava.webp?v=2"},
        {"nazov": "Rádio Rusyn FM", "url": "https://stream.rusyn.fm/rusyny.mp3", "logo": "https://myonlineradio.sk/public/uploads/radio_img/rusyn-fm/play_250_250.webp"},
        {"nazov": "Rádio X - Metal X", "url": "https://stream.radiox.sk:8443/metal.mp3", "logo": "https://myonlineradio.sk/public/uploads/radio_img/radio-x/play_250_250.webp"},
        {"nazov": "Rádio X - Oldies X", "url": "https://stream.radiox.sk:8443/oldies.mp3", "logo": "https://myonlineradio.sk/public/uploads/radio_img/radio-x/play_250_250.webp"},
        {"nazov": "Rádio X - Folklore X", "url": "https://stream.radiox.sk:8443/ludovky.mp3", "logo": "https://myonlineradio.sk/public/uploads/radio_img/radio-x/play_250_250.webp"},
        {"nazov": "Rádio X - Chillout X", "url": "https://stream.radiox.sk:8443/chillout.mp3", "logo": "https://myonlineradio.sk/public/uploads/radio_img/radio-x/play_250_250.webp"},
        {"nazov": "Rádio X - Dance X", "url": "https://stream.radiox.sk:8443/dance.mp3", "logo": "https://myonlineradio.sk/public/uploads/radio_img/radio-x/play_250_250.webp"},
        {"nazov": "Rádio X - DNB X", "url": "https://stream.radiox.sk:8443/dnb.mp3", "logo": "https://myonlineradio.sk/public/uploads/radio_img/radio-x/play_250_250.webp"},
        {"nazov": "Rádio X", "url": "https://stream.radiox.sk:8443/radiox_256.mp3", "logo": "https://myonlineradio.sk/public/uploads/radio_img/radio-x/play_250_250.webp"},
        {"nazov": "Rádio X - Alternative X", "url": "https://stream.radiox.sk:8443/alternative.mp3", "logo": "https://myonlineradio.sk/public/uploads/radio_img/radio-x/play_250_250.webp"},
        {"nazov": "Rádio Vlna - Classic Rock", "url": "https://stream.radiovlna.sk/rock-hi.mp3", "logo": "https://cdn.radia.sk/_radia/loga/coverflow/vlna-classic-rock.png"},
        {"nazov": "Rádio Vlna - Oldies Párty", "url": "https://stream.radiovlna.sk:8000/party-hi.mp3", "logo": "https://cdn.radia.sk/_radia/loga/coverflow/vlna-oldies-party.png"},
        {"nazov": "Rádio Vlna - 60's & 70s", "url": "https://stream.radiovlna.sk/gold-hi.mp3", "logo": "https://cdn.radia.sk/_radia/loga/coverflow/vlna-60s-70s.png"},
        {"nazov": "Rádio Vlna - Balady", "url": "https://stream.radiovlna.sk/balady-hi.mp3", "logo": "https://cdn.radia.sk/_radia/loga/app/vlna-balady.webp?v=1"},
        {"nazov": "Rádio v Nitre", "url": "http://195.210.28.150:8932/radiovnitre_live.mp3", "logo": "https://cdn.radia.sk/_radia/loga/coverflow/radio-v-nitre.png"},
        {"nazov": "Rádio Vega", "url": "https://stream.sepia.sk:8000/vega128.mp3", "logo": "https://cdn.radia.sk/_radia/loga/coverflow/vega.png"},
        {"nazov": "Rádio Tlis", "url": "https://stream.tlis.sk/tlis.mp3", "logo": "https://cdn.radia.sk/_radia/loga/coverflow/tlis.png"},
        {"nazov": "Rádio Topoľčany", "url": "http://80.242.44.249:8000/;", "logo": "https://cdn.radia.sk/_radia/loga/coverflow/topolcany.png"},
        {"nazov": "Radio Slovakia International", "url": "https://icecast.stv.livebox.sk/rsi_128.mp3", "logo": "https://cdn.radia.sk/_radia/loga/coverflow/slovakia-international.png"},
        {"nazov": "Rádio Šírava", "url": "http://stream.sepia.sk:8000/radiosirava.mp3", "logo": "https://cdn.radia.sk/_radia/loga/app/sirava.webp?v=2"},
        {"nazov": "Rádio Rock SV", "url": "https://s2.myradiostream.com/:4870/listen.mp3", "logo": "https://cdn.radia.sk/_radia/loga/coverflow/rock-sv.png"},
        {"nazov": "Rádio Sity", "url": "https://radiosity.online:8000/aac", "logo": "https://cdn.radia.sk/_radia/loga/coverflow/sity.png"},
        {"nazov": "Rádio Pyramída", "url": "https://icecast.stv.livebox.sk/pyramida_128.mp3", "logo": "https://www.radiomix.sk/wp-content/uploads/2024/01/radio-pyramida-560x560.png"},
        {"nazov": "Rádio Rebeca", "url": "https://mpc2.mediacp.eu:8200/rebecaweb", "logo": "https://cdn.radia.sk/_radia/loga/app/rebeca.webp?v=2"},
        {"nazov": "Rádio Pohoda 2", "url": "http://mpc1.mediacp.eu:18111/stream", "logo": "https://cdn.radia.sk/_radia/loga/coverflow/pohoda2.png"},
        {"nazov": "Rádio Pokoj", "url": "http://radioserver.online:8822/;", "logo": "https://cdn.radia.sk/_radia/loga/app/pokoj.webp?v=2"},
        {"nazov": "Rádio Piešťany", "url": "https://solid33.streamupsolutions.com/proxy/gktiemqb/stream", "logo": "https://myonlineradio.sk/public/uploads/radio_img/radio-piestany/play_250_250.webp"},
        {"nazov": "Rádio Pohoda", "url": "https://audio.radiopohoda.com:8000/stream", "logo": "https://myonlineradio.sk/public/uploads/radio_img/radio-pohoda/fb_cover.jpg"},
        {"nazov": "Rádio Paráda", "url": "https://extra.mediacp.eu/stream/RadioParada,o.z.", "logo": "https://www.radiaparada.sk/wp-content/uploads/2021/12/LOGO-PARADA-NEW-1024x1024.png"},
        {"nazov": "Rádio Patria", "url": "https://icecast.stv.livebox.sk/patria_128.mp3", "logo": "https://upload.wikimedia.org/wikipedia/commons/8/85/R%C3%A1dio_PATRIA_LOGO.jpg"},
        {"nazov": "Rádio Modra", "url": "http://185.98.208.12:8000/;", "logo": "https://cdn.radia.sk/_radia/loga/coverflow/modra.png"},
        {"nazov": "Rádio PaF", "url": "https://node-23.zeno.fm/92cv04cggfhvv", "logo": "https://cdn.radia.sk/_radia/loga/coverflow/paf.png"},
        {"nazov": "Rádio Logos", "url": "http://radioserver.online:8824/;", "logo": "https://cdn.radia.sk/_radia/loga/coverflow/logos.png"},
        {"nazov": "Rádio Metropolitan", "url": "https://mpc2.mediacp.eu:8214/stream", "logo": "https://myonlineradio.sk/public/uploads/radio_img/radio-metropolitan/play_250_250.webp"},
        {"nazov": "Rádio Klub", "url": "https://listen.radioking.com/radio/899861/stream/970496", "logo": "https://d3t3ozftmdmh3i.cloudfront.net/staging/podcast_uploaded_nologo/44153165/44153165-1756027969361-fe65b85dada35.jpg"},
        {"nazov": "Rádio Litera", "url": "https://icecast.stv.livebox.sk/litera_128.mp3", "logo": "https://cdn.radia.sk/_radia/loga/coverflow/litera.png"},
        {"nazov": "Rádio KIKS - Big 90s", "url": "https://online.radiokiks.sk:8000/kiks_big90s.mp3", "logo": "https://cdn.radia.sk/_radia/loga/coverflow/kiks-big-90s.png"},
        {"nazov": "Rádio KIKS - Rock Music", "url": "https://online.radiokiks.sk:8000/kiks_rock.mp3", "logo": "https://cdn.radia.sk/_radia/loga/coverflow/kiks-rock-music.png"},
        {"nazov": "Rádio KIKS", "url": "https://online.radiokiks.sk:8000/kiks_hq.mp3", "logo": "https://cdn.radia.sk/_radia/loga/app/kiks.webp?v=1"},
        {"nazov": "Rádio KIKS - Big 80s", "url": "https://online.radiokiks.sk:8000/kiks_big80s.mp3", "logo": "https://radiokiks.net/wp-content/uploads/2024/08/Logo_BIG_80.png"},
        {"nazov": "Rádio Jemné Chillout", "url": "https://stream.bauermedia.sk/chillout-hi.mp3", "logo": "https://cdn.radia.sk/_radia/loga/coverflow/jemne-chillout.png"},
        {"nazov": "Rádio Junior", "url": "https://icecast.stv.livebox.sk/junior_128.mp3", "logo": "https://myonlineradio.sk/public/uploads/radio_img/radio-junior/fb_cover.jpg"},
        {"nazov": "Rádio Janko Hraško", "url": "http://78.24.9.110:31088/;", "logo": "https://myonlineradio.sk/public/uploads/radio_img/radio-janko-hrasko/play_250_250.webp"},
        {"nazov": "Rádio Jazz", "url": "http://stream.sepia.sk:8000/jazz192.mp3", "logo": "http://radiojazz.sk/image/logo.png"},
        {"nazov": "Rádio FanWaves", "url": "https://stream.zeno.fm/gtkbdehhekftv", "logo": "https://images.zeno.fm/ZtUvkDMtkuf8ykYmi9VmIi3zRsaaaKixAoEEe6F5Tzk/rs:fill:288:288/g:ce:0:0/aHR0cHM6Ly9wcm94eS56ZW5vLmZtL2NvbnRlbnQvc3RhdGlvbnMvYzFkZDQwMDYtMjJkNC00NjYyLWIyZGMtZjNjNTVlYmY2YWVlL2ltYWdlLz91PTE3NTUzNjM0NjEwMDA.webp"},
        {"nazov": "Rádio Folk", "url": "https://mpc1.mediacp.eu/stream/demo2", "logo": "https://www.radiofolk.sk/wp-content/uploads/2021/08/cropped-cropped-cropped-Logo-pre-web.png"},
        {"nazov": "Rádio Biblia", "url": "http://radiobiblia.online:8000/stream.ogg", "logo": "https://myonlineradio.sk/public/uploads/radio_img/radio-biblia/play_250_250.webp"},
        {"nazov": "Rádio Extra", "url": "http://live.topradio.cz:8000/extra192", "logo": "https://myonlineradio.cz/public/uploads/radio_img/radio-extra/fb_cover.jpg"},
        {"nazov": "Rádio Beta Česko a Slovenské Hity", "url": "http://109.71.67.102:8000/beta_cspop.mp3", "logo": "https://myonlineradio.sk/public/uploads/radio_img/radio-beta/play_250_250.webp"},
        {"nazov": "Rádio Beta 80'S a 90'S", "url": "http://109.71.67.102:8000/beta_80a90.mp3", "logo": "https://myonlineradio.sk/public/uploads/radio_img/radio-beta/play_250_250.webp"},
        {"nazov": "Rádio Beta Hráme jubilantom", "url": "http://109.71.67.102:8000/beta_jubilanti.mp3", "logo": "https://myonlineradio.sk/public/uploads/radio_img/radio-beta/play_250_250.webp"},
        {"nazov": "Rádio Bela", "url": "http://65.109.81.84:8855/live", "logo": "https://cdn.radia.sk/_radia/loga/coverflow/bela.png"},
        {"nazov": "Rádio Best FM", "url": "https://stream3.bestfm.sk:8000/160.aac", "logo": "https://bestfm.sk/wp-content/uploads/2021/09/logo_transparent.png"},
        {"nazov": "Rádio Basavel", "url": "https://stream.zeno.fm/6gd9c6yn4nhvv", "logo": "https://cdn.radia.sk/_radia/loga/coverflow/basavel.png"},
        {"nazov": "Rádio Aetter", "url": "http://stream.aetter.sk:8000/aetter", "logo": "https://cdn.radia.sk/_radia/loga/app/aetter.webp?v=1"},
        {"nazov": "Rádio 7", "url": "https://play.radio7.sk/128", "logo": "https://cdn.radia.sk/_radia/loga/coverflow/7.png"},
        {"nazov": "Rádio 9", "url": "http://147.232.191.167:8000/high.mp3", "logo": "https://cdn.radia.sk/_radia/loga/coverflow/9.png"},
        {"nazov": "PARTY RADIO", "url": "https://mpc1.mediacp.eu/stream/partyradio", "logo": "http://files.exoweb.eu/13/40/13404079-0cdd-42be-88cd-e832e3e5542c.jpeg"},
        {"nazov": "Rádio Viva", "url": "http://stream.sepia.sk:8000/viva320.mp3", "logo": "https://myonlineradio.sk/public/uploads/radio_img/radio-viva/play_250_250.webp"},
        {"nazov": "Fresh Rádio", "url": "https://icecast2.radionet.sk/freshradio.sk", "logo": "https://myonlineradio.sk/public/uploads/radio_img/fresh-radio/play_250_250.webp"},
        {"nazov": "Rádio Rock", "url": "https://stream.bauermedia.sk/rock-hi.mp3", "logo": "https://radiorock.sk/intro-v2.png"},
        {"nazov": "Rádio Maria Slovakia", "url": "https://dreamsiteradiocp5.com/proxy/radiomariaslomp3?mp=/stream.mp3", "logo": "https://myonlineradio.sk/public/uploads/radio_img/radio-maria-slovensko/play_250_250.webp"},
        {"nazov": "Rádio Lumen", "url": "https://audio.lumen.sk/live128.mp3", "logo": "https://www.radia.sk/_radia/loga/coverflow/lumen.png"},
        {"nazov": "Na vlne Novohradu", "url": "https://radioserver.online/proxy/navlnenovohradu/novohradHQ.mp3", "logo": "https://cdn.radia.sk/_radia/loga/app/navlnenovohradu.webp"},
        {"nazov": "Na vlne Liptova", "url": "http://radioserver.online:8009/hq.mp3", "logo": "https://www.radia.sk/_radia/loga/coverflow/na-vlne-liptova.png"},
        {"nazov": "Mirjam Radio", "url": "https://dreamsiteradiocp5.com/proxy/rmslo?mp=/stream", "logo": "https://www.radia.sk/_radia/loga/app/mirjam.webp?v=1"},
        {"nazov": "METALSCENA netRADIO", "url": "https://listen.radioking.com/radio/263218/stream/308365", "logo": "https://www.radia.sk/_radia/loga/coverflow/metalscena.png"},
        {"nazov": "Mars Dance Rádio", "url": "https://stream.zenolive.com/683gf5xrxfeuv?1686916511841", "logo": "https://www.radia.sk/_radia/loga/app/mars-dance.webp?v=2"},
        {"nazov": "HITRÁDIO SLOVAKIA", "url": "https://hitradioslovakia.stream.laut.fm/hitradioslovakia", "logo": "https://myonlineradio.sk/public/uploads/radio_img/hitradio-slovakia/play_250_250.webp"},
        {"nazov": "BB FM", "url": "http://stream.bbfm.sk:8000/bbfm128.mp3", "logo": "https://myonlineradio.sk/public/uploads/radio_img/bb-fm-radio/play_250_250.webp"},
        {"nazov": "Rádio Regina - Západ", "url": "https://icecast.stv.livebox.sk/regina-ba_128.mp3", "logo": "https://www.radia.sk/_radia/loga/coverflow/regina-zapad.png"},
        {"nazov": "Rádio Regina - Stred", "url": "https://icecast.stv.livebox.sk/regina-bb_128.mp3", "logo": "https://www.radia.sk/_radia/loga/app/regina-stred.webp?v=2"},
        {"nazov": "Rádio Regina - Východ", "url": "https://icecast.stv.livebox.sk/regina-ke_128.mp3", "logo": "https://www.radia.sk/_radia/loga/coverflow/regina-vychod.png"},
        {"nazov": "Rádio Devín", "url": "https://icecast.stv.livebox.sk/devin_128.mp3", "logo": "https://www.radia.sk/_radia/loga/coverflow/devin.png"},
        {"nazov": "Europa 2", "url": "https://stream.bauermedia.sk/europa2-hi.mp3", "logo": "https://www.radia.sk/_radia/loga/coverflow/europa2.png"},
        {"nazov": "Dobré Rádio", "url": "https://stream.dobreradio.sk/dobreradio.mp3", "logo": "https://www.radia.sk/_radia/loga/coverflow/dobre.png"},
        {"nazov": "Rádio InfoVojna", "url": "https://stream1.infovojna.com:8000/live", "logo": "https://topradio.sk/_next/image?url=%2Fimages%2Finfovojna.jpg&w=640&q=75"},
        {"nazov": "Rádio_FM", "url": "https://icecast.stv.livebox.sk/fm_128.mp3", "logo": "https://www.radia.sk/_radia/loga/coverflow/fm.png"},
        {"nazov": "Rádio Dychovka", "url": "https://epanel.mediacp.eu:7661/stream", "logo": "https://www.radia.sk/_radia/loga/app/dychovka.webp?v=1"},
        {"nazov": "Rádio Košice", "url": "http://stream.ecce.sk:8000/radiokosice-128.mp3", "logo": "https://data.tvkosice.sk/images/cm/1000x0xresize/r/a/d/radiokosice/8e/fe/8efe9b31-bd08-4f5d-9168-fa656184fdd2.jpg"},
        {"nazov": "FIT Family RADIO", "url": "http://solid67.streamupsolutions.com:8052/;", "logo": "https://www.radia.sk/_radia/loga/app/fit-family.webp?v=1"},
        {"nazov": "Rádio WOW", "url": "https://radioserver.online:9816/radiowow.mp3", "logo": "https://www.radia.sk/_radia/loga/coverflow/wow.png"},
        {"nazov": "Rádio Slovensko", "url": "https://icecast.stv.livebox.sk/slovensko_128.mp3", "logo": "https://myonlineradio.sk/public/uploads/radio_img/radio-slovensko/play_250_250.webp"},
        {"nazov": "Detské Rádio", "url": "https://stream.21.sk/detskeradio-192.mp3", "logo": "https://data.tvkosice.sk/images/cm/1000x0xresize/r/a/d/radiokosice/08/80/0880daa2-a629-4ce0-9bf9-ab7765572c2f.jpg"},
        {"nazov": "Rádio Frontinus", "url": "http://stream.frontinus.sk:8000/frontinus128.mp3", "logo": "https://myonlineradio.sk/public/uploads/radio_img/radio-frontinus/play_250_250.webp"},
        {"nazov": "Rádio Expres", "url": "https://stream.expres.sk/128.mp3", "logo": "https://www.radia.sk/_radia/loga/coverflow/expres.png"},
        {"nazov": "Rádio Melody", "url": "https://stream.bauermedia.sk/melody-hi.mp3", "logo": "https://www.radiomelody.sk/cover.png?f=raw"},
        {"nazov": "Rádio Beta", "url": "http://109.71.67.102:8000/beta_live_high.mp3", "logo": "https://myonlineradio.sk/public/uploads/radio_img/radio-beta/play_250_250.webp"},
        {"nazov": "Fun Rádio", "url": "https://stream.funradio.sk:8000/fun128.mp3", "logo": "https://myonlineradio.sk/public/uploads/radio_img/fun-radio/play_250_250.webp"},
        {"nazov": "Rádio Vlna", "url": "http://stream.radiovlna.sk/vlna-hi.mp3", "logo": "https://myonlineradio.sk/public/uploads/radio_img/radio-vlna/play_250_250.webp"}
    ]

    radia_cz = [
        {"nazov": "DAB Plus Top 40", "url": "https://ice3.radia.cz/dabtop40.mp3", "logo": "https://www.dabplus-top40.cz/images/DAB-Plus-Top40_logo.jpg"},
        {"nazov": "Dance Club Radio", "url": "http://mp3stream4.abradio.cz/dance128.mp3", "logo": "https://myonlineradio.hu/public/uploads/radio_img/club-dance-radio/play_250_250.webp"},
        {"nazov": "ČRo Vysočina", "url": "https://rozhlas.stream/vysocina_high.aac", "logo": "https://radia-online.com/files/styles/180/public/logo/cesky-rozhlas-vysocina.jpg"},
        {"nazov": "ČRo Zlín", "url": "https://rozhlas.stream/zlin_high.aac", "logo": "https://cdn-profiles.tunein.com/s308134/images/logog.png"},
        {"nazov": "ČRo Střední Čechy", "url": "https://rozhlas.stream/region_high.aac", "logo": "https://radia-online.com/files/styles/180/public/logo/cesky-rozhlas-strednicechy_0.jpg"},
        {"nazov": "ČRo Vltava", "url": "https://rozhlas.stream/vltava_high.aac", "logo": "https://d2emjept89nv7b.cloudfront.net/podcast-covers/458/podcast/2/1000/vltava.jpg"},
        {"nazov": "ČRo Rádiožurnál Sport", "url": "https://rozhlas.stream/radiozurnal_sport_high.aac", "logo": "https://i.ytimg.com/vi/VP-uZQpUfA8/maxresdefault.jpg"},
        {"nazov": "ČRo Sever", "url": "https://rozhlas.stream/sever_high.aac", "logo": "https://images.zeno.fm/pb4SdJj1G0qlswH3pzv7z7ZP2dWJ54qbrER-twZMozQ/rs:fill:288:288/g:ce:0:0/aHR0cHM6Ly9wcm94eS56ZW5vLmZtL2NvbnRlbnQvc3RhdGlvbnMvOGI5M2VkZmYtNTQ5Ny00YjBjLTlhOGEtNDZhMWJlOTQ4YWFmL2ltYWdlLz91PTE3MTM5MDUzNjMwMDA.webp"},
        {"nazov": "ČRo Radio Wave", "url": "https://rozhlas.stream/wave_aac_128.aac", "logo": "https://cdn.sanity.io/images/orhkaa59/production/196ae07e3b024dbe6a38c7692ef51cdc4f5aad61-1000x1000.jpg"},
        {"nazov": "ČRo Rádiožurnál", "url": "https://rozhlas.stream/radiozurnal_low.aac", "logo": "https://informace.rozhlas.cz/sites/default/files/images/03965001.jpeg"},
        {"nazov": "ČRo Prague International", "url": "https://rozhlas.stream/cro7_mp3_128.mp3", "logo": "https://radia-online.com/files/styles/180/public/logo/cesky-rozhlas-radio-prague-international.jpg"},
        {"nazov": "ČRo Rádio Praha", "url": "https://rozhlas.stream/radio_dab_praha_high.aac", "logo": "https://www.liveradio.ie/files/images/107632/resized/180x172c/cx.png"},
        {"nazov": "ČRo Rádio Junior", "url": "https://rozhlas.stream/juniormaxi_mp3_128.mp3", "logo": "https://d2emjept89nv7b.cloudfront.net/podcast-covers/460/podcast/4/1000/radio-junior.jpg"},
        {"nazov": "ČRo Rádio Junior Písničky", "url": "https://rozhlas.stream/radio_junior_high.aac", "logo": "http://api.play.cz/static/radio_logo/t200/crojuniormaxi.png"},
        {"nazov": "ČRo Plzeň", "url": "https://rozhlas.stream/plzen_high.aac", "logo": "https://radia-online.com/files/styles/180/public/logo/cesky-rozhlas-plzen.jpg"},
        {"nazov": "ČRo Pohoda", "url": "https://rozhlas.stream/pohoda_high.aac", "logo": "http://api.play.cz/static/radio_logo/t200/cropohoda.png"},
        {"nazov": "ČRo Pardubice", "url": "https://rozhlas.stream/pardubice_high.aac", "logo": "https://radia-online.com/files/styles/180/public/logo/cesky-rozhlas-pardubice.jpg"},
        {"nazov": "ČRo Plus", "url": "https://rozhlas.stream/plus_high.aac", "logo": "https://radia-online.com/files/styles/media/public/logo/cesky-rozhlas-plus.jpg"},
        {"nazov": "ČRo Olomouc", "url": "https://rozhlas.stream/olomouc_high.aac", "logo": "https://radia-online.com/files/styles/180/public/logo/cesky-rozhlas-olomouc.jpg"},
        {"nazov": "ČRo Ostrava", "url": "https://rozhlas.stream/ostrava_high.aac", "logo": "https://radia-online.com/files/styles/180/public/logo/cesky-rozhlas-ostrava.jpg"},
        {"nazov": "ČRo Karlovy Vary", "url": "https://rozhlas.stream/karlovy_vary_high.aac", "logo": "https://www.boheminium.cz/wp-content/uploads/2015/08/CRo-KV.jpg"},
        {"nazov": "ČRo Liberec", "url": "https://rozhlas.stream/liberec_high.aac", "logo": "https://radia-online.com/files/styles/180/public/logo/cesky-rozhlas-liberec.jpg"},
        {"nazov": "ČRo Hradec Králové", "url": "https://rozhlas.stream/hradec_kralove_high.aac", "logo": "https://radia-online.com/files/styles/180/public/logo/cesky-rozhlas-hradec-kralove.jpg"},
        {"nazov": "ČRo Jazz", "url": "https://rozhlas.stream/jazz_low.aac", "logo": "https://cdn.sanity.io/images/orhkaa59/production/6919323d4e82d622ee98c9284aa724f54b794a39-300x300.png"},
        {"nazov": "ČRo D-dur", "url": "https://rozhlas.stream/ddur_high.aac", "logo": "https://cdn.sanity.io/images/orhkaa59/production/9a9327849aa30ac0b43a91a77da8ad9c0289519d-300x300.png"},
        {"nazov": "ČRo Dvojka", "url": "https://rozhlas.stream/dvojka_high.aac", "logo": "https://images.zeno.fm/E2uXXxWig2gim7BHy_87Zrhcw_oXbsmJ81NroX2Rfo0/rs:fill:288:288/g:ce:0:0/aHR0cHM6Ly9wcm94eS56ZW5vLmZtL2NvbnRlbnQvc3RhdGlvbnMvYTg0YzA3ZWVkLTMyZTAtNGJlYi1hNjNhLTFiNjYyMTcwYzZlNi9pbWFnZS8_dT0xNzEzODczMjM3MDAw.webp"},
        {"nazov": "ČRO Brno", "url": "https://rozhlas.stream/brno_high.aac", "logo": "https://radia-online.com/files/styles/180/public/logo/cesky-rozhlas-brno.jpg"},
        {"nazov": "ČRO České Budějovice", "url": "https://rozhlas.stream/ceske_budejovice_high.aac", "logo": "http://api.play.cz/static/radio_logo/t200/crocb.png"},
        {"nazov": "Český Blaník", "url": "https://playerservices.streamtheworld.com/api/livestream-redirect/RADIO_BLANIKCZ_128.mp3", "logo": "https://radia.cz/media/default/0001/01/663721c3e5e911880a625e89abc926c8c882bce3.svg"},
        {"nazov": "Rádio Impuls", "url": "http://icecast5.play.cz/impuls128.mp3", "logo": "https://myonlineradio.cz/public/uploads/radio_img/radio-impuls/play_250_250.webp"},
        {"nazov": "Crazy Rádio", "url": "http://live.topradio.cz:8000/crazy128", "logo": "http://hit-radio.cz/media/logo_6a043bd4bd019.jpg"},
        {"nazov": "Československé rádio", "url": "http://live.topradio.cz:8000/csradio128", "logo": "https://www.radioexpert.net/radio-logo/czech/%C4%9Beskoslovensk%C3%A9-r%C3%A1dio-232-most-czech-320.jpg"},
        {"nazov": "Coop tip", "url": "http://ice4.abradio.cz/coop128.mp3", "logo": "https://www.radiomix.cz/wp-content/uploads/2022/06/coop-tip-radio-200x200.png"},
        {"nazov": "Country Radio", "url": "https://stream.rcs.revma.com/h7rwanvb938uv", "logo": "https://myonlineradio.cz/public/uploads/radio_img/country-radio/fb_cover.jpg"},
        {"nazov": "ClubRadio", "url": "http://icecast2.play.cz/Clubradio.mp3", "logo": "http://api.play.cz/static/radio_logo/t200/clubradio.png"},
        {"nazov": "Color Music Radio", "url": "http://icecast6.play.cz/color192.mp3", "logo": "https://myonlineradio.cz/public/uploads/radio_img/color-music-radio/play_250_250.webp"},
        {"nazov": "Classic Praha", "url": "https://icecast8.play.cz/classic128.mp3", "logo": "https://static.mytuner.mobi/media/tvos_radios/153/classic-praha.a62cf508.png"},
        {"nazov": "Calimeroclub", "url": "http://live.topradio.cz:8000/calimero192", "logo": "https://www.calimeroclub.eu/img/picture/231/logo-cali.jpg"},
        {"nazov": "Audio Kostel", "url": "https://evcast.mediacp.eu:1585/stream", "logo": "https://www.kostel.cz/logo.png"},
        {"nazov": "Bikers Radio Doupę", "url": "http://icecast7.play.cz/bikersradiodoupe128.mp3", "logo": "https://www.bikersradio.cz/images/logo.png"},
        {"nazov": "Alternative Times Radio", "url": "http://ice3.abradio.cz/alternative128.mp3", "logo": "https://radia.cz/media/images/0001/01/48cd28c2dab73f011e8e64dc0919ef57a7374883.png"},
        {"nazov": "Astra Rádio", "url": "https://astra.icecast.cz/", "logo": "https://myonlineradio.cz/public/uploads/radio_img/astra-radio/fb_cover.jpg"},
        {"nazov": "Rádio Kiss", "url": "https://n25a-eu.rcs.revma.com/asn0cmvb938uv", "logo": "https://www.kiss.cz/files/design/logo.png"},
        {"nazov": "Evropa 2", "url": "https://ice.actve.net/fm-evropa2-128", "logo": "https://www.evropa2.cz/wp-content/themes/evropa2/assets/img/logo.png"},
        {"nazov": "BlackFM Radio", "url": "http://icecast2.play.cz/blackfm-radio-192.mp3", "logo": "https://blackfm.cz/image/freestyle/blackfm_logo_www.jpg"},
        {"nazov": "Blue Radio", "url": "https://stream.blueradio.cz/live", "logo": "https://stream.blueradio.cz/img/logo.png"},
        {"nazov": "Bojler Room", "url": "https://ice4.abradio.cz/bojler_room_128.aac", "logo": "https://radia.cz/media/images/0001/01/5f75dd2c71cc2919a4a9e3b9bac72f341d0780d1.svg"},
        {"nazov": "Bus Radio", "url": "http://mpc1.mediacp.eu:8064/;", "logo": "https://static.mytuner.mobi/media/tvos_radios/ghscgzhhctun.png"}
    ]

    top_sk = [
        {"nazov": "Rádio Slovensko", "url": "https://icecast.stv.livebox.sk/slovensko_128.mp3", "logo": "https://myonlineradio.sk/public/uploads/radio_img/radio-slovensko/play_250_250.webp"},
        {"nazov": "Rádio Expres", "url": "https://stream.expres.sk/128.mp3", "logo": "https://www.radia.sk/_radia/loga/coverflow/expres.png"},
        {"nazov": "Fun Rádio", "url": "https://stream.funradio.sk:8000/fun128.mp3", "logo": "https://myonlineradio.sk/public/uploads/radio_img/fun-radio/play_250_250.webp"},
        {"nazov": "Rádio Vlna", "url": "http://stream.radiovlna.sk/vlna-hi.mp3", "logo": "https://myonlineradio.sk/public/uploads/radio_img/radio-vlna/play_250_250.webp"},
        {"nazov": "Europa 2", "url": "https://stream.bauermedia.sk/europa2-hi.mp3", "logo": "https://www.radia.sk/_radia/loga/coverflow/europa2.png"},
        {"nazov": "Rádio Melody", "url": "https://stream.bauermedia.sk/melody-hi.mp3", "logo": "https://www.radiomelody.sk/cover.png?f=raw"},
        {"nazov": "Rádio Rock", "url": "https://stream.bauermedia.sk/rock-hi.mp3", "logo": "https://radiorock.sk/intro-v2.png"},
        {"nazov": "Rádio_FM", "url": "https://icecast.stv.livebox.sk/fm_128.mp3", "logo": "https://www.radia.sk/_radia/loga/coverflow/fm.png"},
        {"nazov": "Rádio Košice", "url": "http://stream.ecce.sk:8000/radiokosice-128.mp3", "logo": "https://data.tvkosice.sk/images/cm/1000x0xresize/r/a/d/radiokosice/8e/fe/8efe9b31-bd08-4f5d-9168-fa656184fdd2.jpg"},
        {"nazov": "Rádio Vlna - Oldies Párty", "url": "https://stream.radiovlna.sk:8000/party-hi.mp3", "logo": "https://cdn.radia.sk/_radia/loga/coverflow/vlna-oldies-party.png"}
    ]

    top_cz = [
        {"nazov": "Český Blaník", "url": "https://playerservices.streamtheworld.com/api/livestream-redirect/RADIO_BLANIKCZ_128.mp3", "logo": "https://radia.cz/media/default/0001/01/663721c3e5e911880a625e89abc926c8c882bce3.svg"},
        {"nazov": "Rádio Impuls", "url": "http://icecast5.play.cz/impuls128.mp3", "logo": "https://myonlineradio.cz/public/uploads/radio_img/radio-impuls/play_250_250.webp"},
        {"nazov": "Rádio Kiss", "url": "https://n25a-eu.rcs.revma.com/asn0cmvb938uv", "logo": "https://www.kiss.cz/files/design/logo.png"},
        {"nazov": "Evropa 2", "url": "https://ice.actve.net/fm-evropa2-128", "logo": "https://www.evropa2.cz/wp-content/themes/evropa2/assets/img/logo.png"},
        {"nazov": "Country Radio", "url": "https://stream.rcs.revma.com/h7rwanvb938uv", "logo": "https://myonlineradio.cz/public/uploads/radio_img/country-radio/fb_cover.jpg"},
        {"nazov": "Classic Praha", "url": "https://icecast8.play.cz/classic128.mp3", "logo": "https://static.mytuner.mobi/media/tvos_radios/153/classic-praha.a62cf508.png"},
        {"nazov": "Color Music Radio", "url": "http://icecast6.play.cz/color192.mp3", "logo": "https://myonlineradio.cz/public/uploads/radio_img/color-music-radio/play_250_250.webp"},
        {"nazov": "Crazy Rádio", "url": "http://live.topradio.cz:8000/crazy128", "logo": "http://hit-radio.cz/media/logo_6a043bd4bd019.jpg"},
        {"nazov": "Československé rádio", "url": "http://live.topradio.cz:8000/csradio128", "logo": "https://www.radioexpert.net/radio-logo/czech/%C4%9Beskoslovensk%C3%A9-r%C3%A1dio-232-most-czech-320.jpg"},
        {"nazov": "Blue Radio", "url": "https://stream.blueradio.cz/live", "logo": "https://stream.blueradio.cz/img/logo.png"}
    ]

    def create_radio_item(radio, category_name="Počúvam rádio"):
        logo_url = radio['logo'] + '|User-Agent=Mozilla/5.0' if radio.get('logo') else "DefaultAudio.png"
        li = xbmcgui.ListItem(label=radio['nazov'])
        li.setArt({'thumb': logo_url, 'icon': logo_url, 'logo': logo_url, 'clearlogo': logo_url, 'poster': logo_url})
        try:
            info = li.getMusicInfoTag()
            info.setTitle(radio['nazov'])
            info.setArtist([category_name])
            info.setAlbum("Živé internetové vysielanie")
        except:
            pass
        li.setProperty('IsPlayable', 'true')
        li.setProperty('IsRadio', 'true')
        return li

    def add_safe_folder(label, query, icon="DefaultFolder.png"):
        li = xbmcgui.ListItem(label=f"[B]{label}[/B]")
        li.setArt({'icon': icon, 'thumb': icon, 'logo': icon, 'poster': icon})
        try:
            info = li.getMusicInfoTag()
            info.setTitle(label)
            info.setArtist(["Priečinok"])
        except:
            pass
        xbmcplugin.addDirectoryItem(handle, build_url(query), li, isFolder=True)

    # --- ROUTING / NAVIGÁCIA ---
    if action is None:
        xbmcplugin.setContent(handle, 'songs')
        add_safe_folder("🌍 Štáty", {'action': 'submenu_states'})
        add_safe_folder("🆕 Najnovšie pridané", {'action': 'latest_added'})
        add_safe_folder("⭐ Obľúbené", {'action': 'favorites_menu'})
        add_safe_folder("🔍 Vyhľadavanie", {'action': 'search_trigger'})
        xbmcplugin.endOfDirectory(handle, succeeded=True)

    elif action == 'submenu_states':
        xbmcplugin.setContent(handle, 'songs')
        add_safe_folder("🇸🇰 Slovenské rádiá", {'action': 'list_db', 'country': 'sk'}, "https://upload.wikimedia.org/wikipedia/commons/thumb/e/e6/Flag_of_Slovakia.svg/250px-Flag_of_Slovakia.svg.png")
        add_safe_folder("🇨🇿 České rádiá", {'action': 'list_db', 'country': 'cz'}, "https://upload.wikimedia.org/wikipedia/commons/thumb/c/cb/Flag_of_the_Czech_Republic.svg/250px-Flag_of_the_Czech_Republic.svg.png")
        
        li_hu = xbmcgui.ListItem(label="[B]🇭🇺 Maďarské rádiá[/B]")
        li_hu.setArt({'icon': "https://upload.wikimedia.org/wikipedia/commons/thumb/c/c1/Flag_of_Hungary.svg/250px-Flag_of_Hungary.svg.png", 'thumb': "https://upload.wikimedia.org/wikipedia/commons/thumb/c/c1/Flag_of_Hungary.svg/250px-Flag_of_Hungary.svg.png"})
        try:
            li_hu.getMusicInfoTag().setTitle("Maďarské rádiá")
        except:
            pass
        xbmcplugin.addDirectoryItem(handle, build_url({'action': 'hungary_info'}), li_hu, isFolder=False)
        xbmcplugin.endOfDirectory(handle, succeeded=True)

    elif action == 'hungary_info':
        xbmcgui.Dialog().ok("Informácia", "Pripravujeme...")

    elif action == 'latest_added':
        xbmcplugin.setContent(handle, 'songs')
        najnovsie = radia_cz[:2] + radia_sk[:2]
        for radio in najnovsie:
            li = create_radio_item(radio, "Najnovšie pridané")
            play_url = build_url({'action': 'play', 'url': radio['url'], 'nazov': radio['nazov'], 'logo': radio.get('logo', '')})
            xbmcplugin.addDirectoryItem(handle, play_url, li, isFolder=False)
        xbmcplugin.endOfDirectory(handle, succeeded=True)

    elif action == 'favorites_menu':
        xbmcplugin.setContent(handle, 'songs')
        add_safe_folder("🔥 Top 10 SK", {'action': 'list_static', 'type': 'top_sk'})
        add_safe_folder("💥 Top 10 CZ", {'action': 'list_static', 'type': 'top_cz'})
        add_safe_folder("📁 Môj zoznam", {'action': 'my_list'})
        xbmcplugin.endOfDirectory(handle, succeeded=True)

    elif action == 'my_list':
        xbmcplugin.setContent(handle, 'songs')
        add_safe_folder("➕ Pridať vlastnú stanicu", {'action': 'add_custom'})
        for radio in user_data.get("custom", []):
            li = create_radio_item(radio, "Vlastná stanica")
            rem_url = build_url({'action': 'remove_item', 'url': radio['url']})
            li.addContextMenuItems([('Odstrániť vlastnú stanicu', f'RunPlugin({rem_url})')])
            play_url = build_url({'action': 'play', 'url': radio['url'], 'nazov': radio['nazov'], 'logo': radio.get('logo', '')})
            xbmcplugin.addDirectoryItem(handle, play_url, li, isFolder=False)
        xbmcplugin.endOfDirectory(handle, succeeded=True)

    elif action in ['list_db', 'list_static', 'search_results']:
        xbmcplugin.setContent(handle, 'songs')
        vybrane_radia = []
        kat = "Internetové rádio"
        
        if action == 'list_db':
            if params.get('country') == 'sk':
                vybrane_radia = radia_sk
                kat = "Slovenské rádiá"
            else:
                vybrane_radia = radia_cz
                kat = "České rádiá"
        elif action == 'list_static':
            if params.get('type') == 'top_sk':
                vybrane_radia = top_sk
                kat = "Top 10 SK"
            else:
                vybrane_radia = top_cz
                kat = "Top 10 CZ"
        elif action == 'search_results':
            query_str = remove_diacritics(params.get('query', '')).lower()
            vybrane_radia = [
                r for r in (radia_sk + radia_cz) 
                if query_str in remove_diacritics(r['nazov']).lower()
            ]
            kat = "Výsledky vyhľadávania"

        for radio in vybrane_radia:
            li = create_radio_item(radio, kat)
            play_url = build_url({'action': 'play', 'url': radio['url'], 'nazov': radio['nazov'], 'logo': radio.get('logo', '')})
            xbmcplugin.addDirectoryItem(handle, play_url, li, isFolder=False)
        xbmcplugin.endOfDirectory(handle, succeeded=True)

    elif action == 'remove_item':
        url_to_rem = params.get('url')
        user_data["custom"] = [c for c in user_data.get("custom", []) if c['url'] != url_to_rem]
        save_user_data(user_data)
        xbmcgui.Dialog().notification("Odstránené", "Stanica bola vymazaná.", xbmcgui.NOTIFICATION_INFO, 2000)
        xbmc.executebuiltin("Container.Refresh")

    elif action == 'add_custom':
        xbmcplugin.endOfDirectory(handle, succeeded=True)
        
        kb = xbmcgui.DialogKeyboard('', 'Zadaj názov rádia')
        kb.doModal()
        if kb.isConfirmed() and kb.getText():
            name = kb.getText()
            kb_url = xbmcgui.DialogKeyboard('', 'Vlož presnú URL adresu streamu')
            kb_url.doModal()
            if kb_url.isConfirmed() and kb_url.getText():
                stream_url = kb_url.getText()
                new_custom = {"nazov": "[Vlastné] " + name, "url": stream_url, "logo": ""}
                if "custom" not in user_data:
                    user_data["custom"] = []
                user_data["custom"].append(new_custom)
                save_user_data(user_data)
                xbmcgui.Dialog().notification("Úspech", f"Rádio '{name}' pridané!", xbmcgui.NOTIFICATION_INFO, 2500)
        
        xbmc.executebuiltin("Container.Refresh")

    elif action == 'search_trigger':
        xbmcplugin.endOfDirectory(handle, succeeded=True)
        
        kb = xbmcgui.DialogKeyboard('', 'Čo chceš vyhľadať?')
        kb.doModal()
        if kb.isConfirmed() and kb.getText():
            search_query = kb.getText()
            xbmc.executebuiltin(f"Container.Update({build_url({'action': 'search_results', 'query': search_query})})")

    elif action == 'play':
        stream_url = params.get('url')
        nazov_radia = params.get('nazov', 'Internetové rádio')
        logo_radia = params.get('logo', '')
        
        play_item = xbmcgui.ListItem(path=stream_url)
        play_item.setProperty('IsRadio', 'true')
        
        if logo_radia:
            full_logo = logo_radia + '|User-Agent=Mozilla/5.0'
            play_item.setArt({'thumb': full_logo, 'icon': full_logo, 'logo': full_logo, 'clearlogo': full_logo})
            
        try:
            info = play_item.getMusicInfoTag()
            info.setTitle(nazov_radia)
            info.setArtist(["Rádiový stream"])
        except:
            pass
            
        xbmcplugin.setResolvedUrl(handle, True, play_item)

if __name__ == '__main__':
    main()
